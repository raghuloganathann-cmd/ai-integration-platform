# AI Integration Platform (base version)

A small Flask app that routes one chat message to different AI providers.

## Run
    pip install -r requirements.txt
    cp .env.example .env     # add the API keys you have
    python app.py            # open http://localhost:5000

The "Echo (test)" provider works with no keys, so you can check the setup first.

## Add a provider
1. Write `my_provider(message) -> str` in `app.py`.
2. Add it to `PROVIDERS` with a label and its API-key env var.

## Endpoints
- GET  /api/health
- GET  /api/providers
- POST /api/chat   {"provider": "echo", "message": "hello"}
